package com.cg.billing.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

@Repository
public class BillingDaoImpl implements IBillingDao{
	
	@PersistenceContext
	private EntityManager em;
	

	@Override
	public Customer insertCustomer(Customer customer) throws BillingServicesDownException {
		
		em.persist(customer);
		em.flush();
		return customer;
	}

	@Override
	public long insertPostPaidAccount(int customerID,int planId,PostpaidAccount account) {
		
		em.persist(account);
		em.flush();
		return 1;
	}

	@Override
	public boolean updatePostPaidAccount(int customerID, PostpaidAccount account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double insertMonthlybill(int customerID, long mobileNo, Bill bill) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Plan insertPlan(Plan plan) throws PlanDetailsNotFoundException {
		em.persist(plan);
		em.flush();
		return plan;
	}

	@Override
	public boolean deletePostPaidAccount(int customerID, long mobileNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Bill getMonthlyBill(int customerID, long mobileNo, String billMonth) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBills(int customerID, long mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerPostPaidAccounts(int customerID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomer(int customerID) {
		Query queryOne = em.createQuery(" From Customer ");
		Customer Customer = (com.cg.billing.beans.Customer) queryOne.getResultList();
		
		return Customer;
		
	}

	@Override
	public List<Customer> getAllCustomers() {
		Query queryOne = em.createQuery(" From Customer");
		List<Customer> allCustomer = queryOne.getResultList();
		System.out.println(allCustomer);
		return allCustomer;
		
	}

	@Override
	public List<Plan> getAllPlans() {
		Query queryTwo = em.createQuery(" From Plan");
		List<Plan> allplan = queryTwo.getResultList();
		return allplan;
	}

	@Override
	public Plan getPlan(int planID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostpaidAccount getCustomerPostPaidAccount(int customerID, long mobileNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostpaidAccount getPlanDetails(int customerID, long mobileNo) throws PostpaidAccountNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCustomer(int customerID) {
		Customer customer=em.find(Customer.class,customerID);
		em.remove(customer);
		
	}

	@Override
	public long insertPostPaidAccount(int customerID, PostpaidAccount account) {
		// TODO Auto-generated method stub
		return 0;
	}

}
