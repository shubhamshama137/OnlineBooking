package com.cg.billing.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.services.IBillingServices;


@RestController
public class BillingController {
	
	@Autowired
	private IBillingServices services;
	
	//Accept Customer Details
	@RequestMapping(value="/acceptCustomerDetail",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>acceptProductDetail(@ModelAttribute Customer customer) throws BillingServicesDownException{
		services.acceptCustomerDetails(customer);
		return new ResponseEntity<>("Customer details succesfully added",HttpStatus.OK);
		
	}
	
	//Show All Customer Details
	@RequestMapping(value="/showCustomerDetailJSON",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Customer>> getCustomerDetails(@ModelAttribute Customer customer) throws BillingServicesDownException{
		
	List<Customer> cust = services.getAllCustomerDetails();
		return new ResponseEntity<>(cust,HttpStatus.OK);
		
	}
	
	//Delete Customer Details
	@RequestMapping(value="/deleteCustomer/{customerID}",method=RequestMethod.DELETE)
	public ResponseEntity<String>deletecustomerDetail(@PathVariable("customerID") int customerID) throws BillingServicesDownException, CustomerDetailsNotFoundException{
		services.deleteCustomer(customerID);
		return new ResponseEntity<>("Customer details succesfully deleted",HttpStatus.OK);
		
	}

	//Insert Plans
	@RequestMapping(value="/insertPlan",method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>insertPlan1(@ModelAttribute Plan plan) throws PlanDetailsNotFoundException, BillingServicesDownException{
		services.insertPlan(plan);
		return new ResponseEntity<>("plan successfully added",HttpStatus.OK);
		
	}
	
	//Get All Plans
	@RequestMapping(value="/showallPlans",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Plan>> showallPlans(@ModelAttribute Customer customer) throws PlanDetailsNotFoundException, BillingServicesDownException{
		
	List<Plan> plan = services.getPlanAllDetails();
		return new ResponseEntity<>(plan,HttpStatus.OK);
		
	}
	
	//open postpaid account
	@RequestMapping(value = "/openPostpaidMobileAccount", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> openPostpaidMobileAccount(@ModelAttribute PostpaidAccount account)
			throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		System.out.println("Controller");
		System.out.println(account.getCustomer().getCustomerID());
		services.openPostpaidMobileAccount(account.getCustomer().getCustomerID(), account.getPlan().getPlanID(),
				account);
		return new ResponseEntity<>(
				"PostPaid account details succesfully added with mobile number" + account.getMobileNo(), HttpStatus.OK);
	}
	

	//Show All Customer Details
		@RequestMapping(value="/showpostpaidaccounts/{customerID}",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<PostpaidAccount> showAllpostpaidaccounts(@PathVariable("customerID") int customerID ) throws BillingServicesDownException, CustomerDetailsNotFoundException{
			
		PostpaidAccount acc = services.getCustomerAllPostpaidAccountsDetails(customerID);

			return new ResponseEntity<>(acc,HttpStatus.OK);
			
		}
		
}
